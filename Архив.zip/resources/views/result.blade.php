<div id="questions">
  <div></div>
  <div></div>
  <div></div>
  <div id="point"></div>
  <div></div> <!-- удалить -->
  <div></div> <!-- удалить -->
  <div></div> <!-- удалить -->
  <div></div> <!-- удалить -->
  <!-- ... -->
  <!-- ... -->
</div>

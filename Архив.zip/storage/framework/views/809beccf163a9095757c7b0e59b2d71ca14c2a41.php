<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<div id="app">
    <test></test>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Checker/resources/views/vue.blade.php ENDPATH**/ ?>